SELECT * FROM acceso1 
WHERE usuario='$usuario' 
AND clave='$clave' 
AND estado='a';
-- MODELOS DE ENCRIPTACION
-- MD5 - 40 caracteres
-- SHA1 - 128 caracteres

SELECT * FROM acceso1 
UNION SELECT 1
WHERE usuario='$usuario' 
AND clave='$clave' 
AND estado='a';

CREATE VIEW vAcceso AS 
SELECT * FROM acceso1 
WHERE estado='a';

SELECT * FROM vAcceso;

DELIMITER $$
CREATE PROCEDURE spLogin(IN params1 VARCHAR(45), IN params2 VARCHAR(45))
BEGIN
    SELECT * FROM vAcceso WHERE usuario=params1 
    AND clave=params2 
    AND estado='a';
END$$
DELIMITER ;

CALL spLogin('mdono','123');

{
    "usuario": "mdono' or '1'='1' --",
    "clave": "abc"
}

SELECT * FROM acceso WHERE usuario='mdono' or 1=1 -- ' AND clave='123'

DELIMITER $$
CREATE OR REPLACE PROCEDURE `spLogin2` (
	IN `_gestion` VARCHAR(5), 
	IN `_user` VARCHAR(45), 
	IN `_pass` VARCHAR(32), 
	IN `_token` VARCHAR(32)
)  SQL SECURITY INVOKER 
BEGIN 

DECLARE usuario_login INT;
DECLARE usuario_logout INT;
DECLARE usuario_nombre VARCHAR(20);
DECLARE usuario_token VARCHAR(32);
DECLARE usuario_actualizado INT;

SET @varUsuario := _user;
SET @varContrasena := _pass;
SET @varGestion := _gestion;
SET @varToken := _token;
SET @varBaseToken:= (SELECT UPPER(MD5(CONCAT(correlativo, usuario, clave, (SELECT CURRENT_TIMESTAMP())))) AS token FROM `acceso1` WHERE usuario = @varUsuario AND estado = 'a' LIMIT 1);
SET @varCreacion := (SELECT CURRENT_TIMESTAMP());
SET usuario_login := -1;
SET usuario_logout := -1;
SET usuario_actualizado := -1;
SET usuario_nombre := NULL;
SET usuario_token := NULL;

BEGIN DECLARE EXIT HANDLER FOR 1062 BEGIN ROLLBACK;
SELECT 'Error de llave duplicada' as mensaje;
END;

DECLARE EXIT HANDLER FOR 1048 BEGIN ROLLBACK;
SELECT 'Ingresando un valor NULL en un campo NOT NULL' as mensaje;
END;

DECLARE CONTINUE HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK;
SELECT 'Error de SQLException' as mensaje;
END;

DECLARE EXIT HANDLER FOR SQLSTATE '23000' BEGIN ROLLBACK;
SELECT 'SQLSTATE: 23000 (ER_DUP_KEY)' as mensaje;
END;

-- recuperando la data
BEGIN 
	IF @varGestion IS NOT NULL
  	AND @varUsuario IS NOT NULL 
  	AND @varContrasena IS NOT NULL 
  	THEN 
  		CASE @varGestion 
		WHEN 'in' THEN 
			-- RECUPERANDO LA INFO.
			SELECT token INTO usuario_token FROM `acceso_sesion1` 
            WHERE usuario = @varUsuario AND flag = 'in' AND estado = 'a';

			SELECT nombre INTO usuario_nombre FROM `acceso1` 
            WHERE usuario = @varUsuario AND estado = 'a' LIMIT 1;

			SELECT COUNT(token) INTO usuario_login FROM `acceso_sesion1` 
			WHERE usuario = @varUsuario AND flag = 'in' AND estado = 'a';

			-- SELECT usuario_login AS mensaje;

			IF usuario_login IS NOT NULL THEN 
				CASE usuario_login  
				WHEN -1 THEN 
					SELECT CONCAT("Error al recuperar el usuario ", usuario_nombre) AS mensaje;

					SET usuario_login := NULL;
					SET usuario_nombre := NULL;
					SET usuario_token := NULL;
				WHEN 0 THEN 
					-- CREANDO EL TOKEN
					INSERT INTO `acceso_sesion1`(
						`usuario`,`flag`,`token`
					) VALUES (
			    		@varUsuario, 
			    		'IN', 
			    		@varBaseToken
					);

					SELECT 
                        `a`.`correlativo` AS id, 
                        `a`.`nombre` AS nombre, 
                        `a`.`usuario` AS usuario, 
                        `a`.`perfil` AS perfil, 
                        `s`.`flag` AS flag, 
                        `s`.`token` AS token 
					FROM `acceso1` a 
					JOIN `acceso_sesion1` s ON `s`.`usuario` = `a`.`usuario` 
                    WHERE `s`.`usuario` = @varUsuario 
                    AND `a`.`estado` = 'a' 
                    AND `s`.`estado` = 'a' 
                    AND `s`.`flag` = 'in';

					SET usuario_login := NULL;
					SET usuario_nombre := NULL;
					SET usuario_token := NULL;
				WHEN 1 THEN 
					SELECT CONCAT("El usuario ", usuario_nombre, " esta activo ", usuario_login, " vez con token ", usuario_token) AS mensaje;

					SET usuario_login := NULL;
					SET usuario_nombre := NULL;
					SET usuario_token := NULL;
				ELSE 
					SELECT CONCAT("El usuario ", usuario_login, " esta activo con nombre ", usuario_nombre, " y token ", usuario_token) AS mensaje;

					SET usuario_login := NULL;
					SET usuario_nombre := NULL;
					SET usuario_token := NULL;
				END CASE;
			END IF;
		WHEN 'out' THEN 
			IF @varUsuario IS NOT NULL 
			AND @varToken IS NOT NULL 
			THEN 
				-- RECUPERA USUARIO LOGIN.
				SELECT COUNT(token) INTO usuario_login FROM `acceso_sesion1` 
                WHERE usuario = @varUsuario 
                AND token = @varToken 
                AND flag = 'in' 
                AND estado = 'a';

				IF usuario_login IS NOT NULL THEN 
					CASE usuario_login  
					WHEN -1 THEN 
						SELECT CONCAT("El usuario ", @varUsuario, " y token no encontrado.", usuario_login) AS mensaje;

						SET usuario_login := NULL;
					WHEN 0 THEN 
						SELECT CONCAT("El usuario ", @varUsuario, " y token no encontrado.", usuario_login) AS mensaje;

						SET usuario_login := NULL;
					WHEN 1 THEN 
						-- CREANDO EL TOKEN
						INSERT INTO `acceso_sesion1`(`usuario`,`flag`,`token`) 
				    	VALUES(
				    		@varUsuario, 
				    		'OUT', 
				    		@varToken
						);

						-- RECUPERANDO LA INFO.
						SELECT COUNT(token) INTO usuario_logout FROM `acceso_sesion1` WHERE usuario = @varUsuario AND token = @varToken AND flag = 'out' AND estado = 'a';

						-- SELECT usuario_logout AS mensaje;

						IF usuario_logout IS NOT NULL THEN 
							CASE usuario_login  
							WHEN -1 THEN 
								SELECT CONCAT("El usuario ", @varUsuario, " y token no encontrado.") AS mensaje;
							WHEN 0 THEN 
								SELECT CONCAT("El usuario ", @varUsuario, " y token no encontrado.") AS mensaje;
							WHEN 1 THEN 
								-- ACTUALIZA LA INFO.
								UPDATE `acceso_sesion1` SET estado = 'n' WHERE usuario = @varUsuario AND token = @varToken AND flag = 'in' AND fecha_creacion < (SELECT CURRENT_TIMESTAMP()) AND estado = 'a';

								-- RECUPERANDO LA INFO.
								SELECT COUNT(token) INTO usuario_actualizado FROM `acceso_sesion1` WHERE usuario = @varUsuario AND token = @varToken AND flag = 'in' AND estado = 'n';

								IF usuario_actualizado IS NOT NULL THEN 
									-- SELECT usuario_actualizado AS mensaje;
									SELECT CONCAT("El usuario ", @varUsuario, " ha desingresado correctamente.") AS mensaje;
								END IF;
							ELSE 
								SELECT CONCAT("El usuario ", @varUsuario, " y token no encontrado.") AS mensaje;
							END CASE;
						END IF;
						SET usuario_login := NULL;
					WHEN 2 THEN 
						SELECT CONCAT("El usuario ", @varUsuario, " y token no encontrado.") AS mensaje;

						SET usuario_login := NULL;
					WHEN 3 THEN 
						SELECT CONCAT("El usuario ", @varUsuario, " y token no encontrado.") AS mensaje;
					ELSE 
						SELECT CONCAT("El usuario ", @varUsuario, " y token no encontrado.") AS mensaje;

						SET usuario_login := NULL;
					END CASE;
				END IF;

				-- RECUPERANDO LA INFO.
				SELECT usuario, flag, token, fecha_creacion FROM `acceso_sesion1` 
                WHERE usuario = @varUsuario 
                AND token = @varToken 
                AND flag = 'IN' 
                -- AND fecha_creacion < @varCreacion 
                AND estado = 'a';
			ELSE 
				SELECT 'valores vacios' as mensaje;
			END IF;
		END CASE;

		SET usuario_login := NULL;
		SET usuario_nombre := NULL;
		SET usuario_token := NULL;
	ELSE 
		SELECT 'valores vacios' as mensaje;
	END IF;

	SET usuario_login := NULL;
	SET usuario_nombre := NULL;
	SET usuario_token := NULL;
END;END;END$$