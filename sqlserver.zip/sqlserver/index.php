<?php
//DESHABILITANDO EL MOSTAR ERRORES
/*
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(-1);
*/

header('content-type: application/json; charset=utf-8');
require_once 'productos.php';
$productoModelo = new productoModelo();

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        //echo 'Solicitud GET';
        $respuesta = $productoModelo->getProducto();
        echo json_encode($respuesta);
        break;
    case 'POST':
        //echo 'Solicitud POST';
        $_POST = json_decode(file_get_contents('php://input', true));

        if (!isset($_POST->usuario) || is_null($_POST->usuario) || empty(trim($_POST->usuario))) {
            $respuesta = ['error','El usuario no debe de estar vacio'];
        } else if (!isset($_POST->clave) || is_null($_POST->clave) || empty(trim($_POST->clave))) {
            $respuesta = ['error','La clave no debe de estar vacia'];
        /*} else if (!isset($_POST->perfil) || is_null($_POST->perfil) || empty(trim($_POST->perfil))) {
            $respuesta = ['error','El perfil no debe de estar vacio'];*/
        } else {
            //$respuesta = $productoModelo->guardarProducto($_POST->usuario, $_POST->clave, $_POST->perfil);
            //$respuesta = $productoModelo->getProductoData($_POST->usuario, $_POST->clave);
            $respuesta = $productoModelo->getProductoData($_POST->gestion, $_POST->usuario, $_POST->clave, $_POST->token);
        }

        echo json_encode($respuesta);
        //print_r(json_encode($respuesta));
        break;
    case 'PUT':
        echo 'Solicitud PUT';
        break;
    case 'DELETE':
        //echo 'Solicitud DELETE';
        $_DELETE = json_decode(file_get_contents('php://input', true));

        if (!isset($_DELETE->id) || is_null($_DELETE->id) || empty(trim($_DELETE->id))) {
            $respuesta = ['error','El ID no debe de estar vacio'];
        } else {

        }
        break;
}
