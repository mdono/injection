<?php
class productoModelo
{
    public $conn;

    public function __construct()
    {
        $this->conn = new mysqli('localhost', 'root', '', 'chat');
        mysqli_set_charset($this->conn, 'utf8');
        // mysqli_next_result($this->conn);
    }

    public function getProducto()
    {
        $productos = [];
        $query = "SELECT * FROM acceso WHERE estado='a' ";
        $registros = mysqli_query($this->conn, $query);

        while ($fila = mysqli_fetch_assoc($registros)) {
            if ($fila > 0) {
                array_push($productos, $fila);
            }
        }

        return $productos;
    }

    //public function getProductoData($x, $y)
    public function getProductoData($a, $b, $c, $d)
    {
        $token = null;
        $productos = [];
        $token = $d;
        
        /*
        if (empty($token) || $token=='') {
            $token = null;
        }*/

        //array_push($productos, $a, $b, $c, $token);

        //return $productos;
        $query = "SELECT * FROM acceso1 WHERE usuario='$b' AND clave='$c' ";
        //$query = "SELECT * FROM vAcceso WHERE usuario='$b' AND clave='$c' AND estado='a' ";
        //$query = "CALL spLogin2('$a','$b','$c','$d')";
        //return $query;

        $registros = mysqli_query($this->conn, $query);

        while ($fila = mysqli_fetch_assoc($registros)) {
            array_push($productos, $fila);
        }

        // mysqli_free_result($registros);

        return $productos;
    }

    public function guardarProducto($usuario, $clave, $perfil)
    {
        $query = "INSERT INTO acceso(usuario, clave, perfil) VALUES('$usuario', '$clave', '$perfil')";

        mysqli_query($this->conn, $query);
        $resultado = ['success', 'Almacenado correctamente!'];

        return $resultado;
    }

    public function actualizaProducto($id, $usuario, $clave, $perfil)
    {
        $query = "UPDATE acceso SET usuario='$usuario', clave='$clave', perfil='$perfil' WHERE correlativo=$id";

        mysqli_query($this->conn, $query);
        $resultado = ['success', 'Eliminado exitosamente!'];

        return $resultado;
    }

    public function eliminaProducto($id)
    {
        $query = "DELETE FROM acceso WHERE correlativo=$id";

        mysqli_query($this->conn, $query);
        $resultado = ['success', 'Eliminado exitosamente!'];

        return $resultado;
    }
}
